document.addEventListener('DOMContentLoaded', async () => {
    const llmSelect = document.getElementById('llm-select');
    const modelSelect = document.getElementById('model-select');
    const chartTypeSelect = document.getElementById('chart-type-select');
    const apiKeySection = document.getElementById('api-key-section');
    const generateBtn = document.getElementById('generate-btn');
    const promptText = document.getElementById('prompt');
    const chartContainer = document.getElementById('chart-container');
    const loader = document.getElementById('loader');
    const statusMessage = document.getElementById('status-message');

    const llmModels = {
        gemini: ['gemini-1.5-pro-latest'],
        groq: ['llama3-8b-8192', 'llama3-70b-8192', 'mixtral-8x7b-32768']
    };

    // Populate LLM and Chart Type dropdowns
    const llms = await eel.get_llms()();
    llms.forEach(llm => {
        const option = document.createElement('option');
        option.value = llm;
        option.textContent = llm.charAt(0).toUpperCase() + llm.slice(1);
        llmSelect.appendChild(option);

        // Create API key input fields
        const div = document.createElement('div');
        div.className = 'api-key-input';
        div.innerHTML = `
            <label for="${llm}-key">${llm.toUpperCase()} API Key</label>
            <input type="password" id="${llm}-key" placeholder="Enter your key">
            <button class="save-key-btn" data-provider="${llm}">Save & Configure</button>
        `;
        apiKeySection.appendChild(div);
    });

    const chartTypes = await eel.get_chart_types()();
    chartTypes.forEach(type => {
        const option = document.createElement('option');
        option.value = type;
        option.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        chartTypeSelect.appendChild(option);
    });
    
    // Update models when LLM changes
    function updateModels() {
        const selectedLlm = llmSelect.value;
        modelSelect.innerHTML = '';
        llmModels[selectedLlm].forEach(model => {
            const option = document.createElement('option');
            option.value = model;
            option.textContent = model;
            modelSelect.appendChild(option);
        });
    }

    llmSelect.addEventListener('change', updateModels);
    updateModels();

    // Save API Key
    apiKeySection.addEventListener('click', async (e) => {
        if (e.target.classList.contains('save-key-btn')) {
            const provider = e.target.dataset.provider;
            const keyInput = document.getElementById(`${provider}-key`);
            const key = keyInput.value;
            if (!key) {
                alert('Please enter an API key.');
                return;
            }
            
            statusMessage.textContent = `Saving and configuring ${provider} key...`;
            loader.style.display = 'block';
            
            const result = await eel.save_key({ provider, key })();
            
            loader.style.display = 'none';
            if (result.status === 'success') {
                statusMessage.textContent = `Key for ${provider} saved. Config check: ${result.config_result}`;
                alert(`Key for ${provider} saved. Config check: ${result.config_result}`);
            } else {
                statusMessage.textContent = `Error: ${result.detail}`;
                alert(`Error: ${result.detail}`);
            }
        }
    });

    // Generate Chart
    generateBtn.addEventListener('click', async () => {
        const prompt = promptText.value;
        if (!prompt) {
            alert('Please enter a prompt.');
            return;
        }

        chartContainer.innerHTML = '';
        chartContainer.appendChild(loader);
        loader.style.display = 'block';

        const request = {
            prompt: prompt,
            llm: llmSelect.value,
            model: modelSelect.value,
            chart_type: chartTypeSelect.value
        };

        const result = await eel.generate(request)();
        
        loader.style.display = 'none';

        if (result && !result.error) {
            Plotly.newPlot(chartContainer, result.data, result.layout);
        } else {
            chartContainer.innerHTML = `<div id="status-message">Error: ${result.error || 'Failed to generate chart.'}<br><pre>${result.raw_response || ''}</pre></div>`;
        }
    });
});
